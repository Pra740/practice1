#include <iostream>
#include<stack>
using namespace std;

class bst;
class node
{
private:
	node* left;
	float data;
	node* right;
public:
	node(float data)
	{
		this->left = NULL;
	    this->data= data;
		this->right = right;
	}
	friend class bst;
};
class bst
{
private:
	node* root;
public:
	bst()
    {
		this->root = NULL;
    }
	bool isEmpty()
	{
		return( this->root == NULL);
	}



	void addNode(float data)
	{
		node *newnode = new node(data);

		if( isEmpty())
		{
			this->root = newnode;
		}
		else
		{
			node* trav = root;

			while(1)
			{
				if(data < trav->data)
				{
					if(trav->left == NULL)
					{
						trav->left= newnode;
						break;
					}
					else
					{
						trav=trav->left;
					}
				}
				else
				{
					if(trav->right == NULL)
					{
						trav->right= newnode;
						break;
					}
					else
					{
						trav=trav->right;
					}
				}
			}
		}
	}

	void search(float key)
	{
		if(key == NULL)
			return;
		node *trav = root;

		while(trav != NULL)
		{
			if(key == trav->data)
			{
				cout<<"Node is found  !!!"<<endl;
				break;
			}

			if(key < trav->data)
			{
				trav = trav->left;
			}
			else
			{
				trav=trav->right;
			}
		}
	}
	void inOrder()
	{
		if(! isEmpty())
		{
			inOrder(root);
		}
	}
	void inOrder(node * trav)
	{
		if(trav == NULL)
			return ;

		inOrder(trav->left);
		cout<<trav->data<<" ";
		inOrder(trav->right);

	}
	void postOrder()
	{
		if(! isEmpty())
		{
			postOrder(root);
		}
	}
	void postOrder(node * trav)
	{
		if(trav == NULL)
			return ;

		postOrder(trav->left);
		postOrder(trav->right);
		cout<<trav->data<<" ";
	}

	void preOrder()
	{
		node* trav = root;

		stack<node *> s;

		s.push(root);

		while(trav != NULL || ! s.empty())
		{
			//cout<<"H2...."<<endl;
			trav= s.top();
			s.pop();
			cout<<trav->data<<" ";

			if(trav->left != NULL)
			{
				trav = trav->left;
				s.push(trav);
			}
			else
			{

			}
			if(trav->right != NULL)
			{
				trav=trav->right;
				s.push(trav);
			}
			else
			{

			}
		}
	}

     void height(float key)
     {
    	node*trav= root;
    	int h=4;

    	while(trav != NULL)
    	{
    		if(key == trav->data)
    		{
    			cout<<"Height is "<<h<<endl;
    			h--;
    			break;
    		}

    		if(key < trav->data)
    		{
    			trav = trav->left;
    			h--;
    		}
    		else
    		{
    			trav=trav->right;
    			h--;
    		}
    	}

     }
     ~bst()
     {
    	 if( ! isEmpty())
    	 {
    		 clear(root);
    		 cout<<"BST is Free !!!";
    	 }
     }
     void clear(node *trav)
     {
    	 if (trav!=NULL)
    	 {
    		 node*trav = root;
    		 clear(trav->left);
    		 clear(trav->right);
    		 delete trav;
    	 }
     }
};

enum menu{EXIT,ADD,SEARCH,INORDER,POSTORDER,PREORDER,HEIGHT};

int menu_list()
{
	int choice;
	cout<<endl;
	cout<<"0.EXIT"<<endl;
	cout<<"1.ADD"<<endl;
	cout<<"2.SEARCH"<<endl;
	cout<<"3.INORDER"<<endl;
	cout<<"4.POSTORDER"<<endl;
	cout<<"5.PREORDER"<<endl;
	cout<<"6.HEIGHT"<<endl;
	cout<<"Enter Choice::";
	cin>>choice;
	return choice;
}


int main() {
	bst t;
    int choice;
    float data;

    while(1)
      {
      	choice =menu_list();
      	switch(choice)
      	{
      	case EXIT:
      		     return 0;
      	case ADD:
      		 cout<<"Value of Node::";
      		 cin>>data;
      		 t.addNode(data);
      	    		break;
      	case SEARCH:
      		 cout<<"Search Key::";
      		 cin>>data;
      		t.search(data);
      		 cout<<endl;
      	    		break;
      	case INORDER:
      		t.inOrder();
      		cout<<endl;
      	    		break;

      	case POSTORDER:
      		t.postOrder();
      		cout<<endl;
      	    		break;

      	case PREORDER:
      		t.preOrder();
      	    cout<<endl;
      	    		break;

      	case HEIGHT:
      		cout<<"Search Key::";
      		cin>>data;
      		 t.height(data);
      		 cout<<endl;
      	    break;
      	}
      }
	return 0;
}
