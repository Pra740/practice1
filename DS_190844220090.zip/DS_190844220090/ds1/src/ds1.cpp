
#include <iostream>
#include<stack>
using namespace std;

class bst;
class node
{
private:
	node* left;
	float data;
	node* right;
public:
	node(float data)
	{
		this->left = NULL;
	    this->data= data;
		this->right = right;
	}
	friend class bst;
};
class bst
{
private:
	node* root;
public:
	bst()
    {
		this->root = NULL;
    }
	bool isEmpty()
	{
		return( this->root == NULL);
	}



	void addNode(float data)
	{
		node *newnode = new node(data);

		if( isEmpty())
		{
			this->root = newnode;
		}
		else
		{
			node* trav = root;

			while(1)
			{
				if(data < trav->data)
				{
					if(trav->left == NULL)
					{
						trav->left= newnode;
						break;
					}
					else
					{
						trav=trav->left;
					}
				}
				else
				{
					if(trav->right == NULL)
					{
						trav->right= newnode;
						break;
					}
					else
					{
						trav=trav->right;
					}
				}
			}
		}
	}

	void search(float key)
	{
		if(key == NULL)
			return;
		node *trav = root;

		while(trav != NULL)
		{
			if(key == trav->data)
			{
				cout<<"Node is found  !!!"<<endl;
				break;
			}

			if(key < trav->data)
			{
				trav = trav->left;
			}
			else
			{
				trav=trav->right;
			}
		}

		cout<<"Node is not Found...."<<endl;
	}
	void inOrder()
	{
		if(! isEmpty())
		{
			inOrder(root);
		}
	}
	void inOrder(node * trav)
	{
		if(trav == NULL)
			return ;

		inOrder(trav->left);
		cout<<trav->data<<" ";
		inOrder(trav->right);

	}
	void postOrder()
	{
		if(! isEmpty())
		{
			postOrder(root);
		}
	}
	void postOrder(node * trav)
	{
		if(trav == NULL)
			return ;

		postOrder(trav->left);
		postOrder(trav->right);
		cout<<trav->data<<" ";
	}

	void preOrder()
	{
		node* parent = NULL;
		node* trav = root;

		stack<node *> s;

		s.push(root);
		cout<<"H1...."<<endl;

		while(trav != NULL || ! s.empty())
		{
			//cout<<"H2...."<<endl;
			trav= s.top();
			s.pop();
			cout<<trav->data<<" ";

			if(trav->left != NULL)
			{
				//cout<<"H3...."<<endl;
				trav = trav->left;
				s.push(trav);
			}
			else
			{

			}
			if(trav->right != NULL)
			{
				//cout<<"H4...."<<endl;
				trav=trav->right;
				s.push(trav);
			}
			else
			{

			}
     cout<<"H5";
		}
	}

     void height(float key)
     {
    	node*trav= root;
    	int h=4;

    	while(trav != NULL)
    	{
    		if(key == trav->data)
    		{
    			cout<<"Height is "<<h<<endl;
    			h--;
    			break;
    		}

    		if(key < trav->data)
    		{
    			trav = trav->left;
    			h--;
    		}
    		else
    		{
    			trav=trav->right;
    			h--;
    		}
    	}

     }





};
int main() {
	bst t[]={50.2,25.3,15.9,75.5,90.6,40.3,60.1,10.8,30.3,45.2,70.8};

	for(int i=0;i<11;i++)
	{
		t.addNode(i);
	}

//	t.addNode(50.2);
//	t.addNode(25.3);
//	t.addNode(15.9);
//	t.addNode(75.5);
//	t.addNode(90.6);
//	t.addNode(40.3);
//	t.addNode(60.1);
//	t.addNode(10.8);
//	t.addNode(30.3);
//	t.addNode(45.2);
//	t.addNode(70.8);

//	t.preOrder();
//     cout<<endl;
//	t.inOrder();
//	cout<<endl;
//	t.postOrder();
//	cout<<endl;
//
//	t.search(15.5);
//    cout<<endl;

     t.height(25.3);
      cout<<endl;
	return 0;
}
